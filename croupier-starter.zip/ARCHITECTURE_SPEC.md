# Specification: @yabbadabbadev/croupier
**Version:** 1.0.0  
**Package:** `@yabbadabbadev/croupier`  
**Binary:** `croupier`  
**Paradigm:** Deterministic Multi-Agent State Machine (Graph-based SDD)

Revisar implementación y topología en src/ y tests/.
