import { describe, it, expect } from "vitest";
import { evaluateVerificationState } from "../../src/arbiter/jev-arbiter.js";
import { VerificationResult } from "../../src/state/types.js";

describe("Jev Arbiter: Deterministic Decision Engine", () => {
  it("avanza a a11y cuando el resultado es positivo", () => {
    const verification: VerificationResult = {
      passed: true,
      typeCheckPassed: true,
      unitTestsPassed: true,
      output: "All tests green",
      failedTestNames: [],
    };

    const result = evaluateVerificationState(verification, 3);
    expect(result.action).toBe("PROCEED_TO_A11Y");
    expect(result.remainingRetries).toBe(3);
  });

  it("ordena reintentar implementación decrementando el contador si quedan intentos", () => {
    const verification: VerificationResult = {
      passed: false,
      typeCheckPassed: true,
      unitTestsPassed: false,
      output: "AssertionError: expected true to be false",
      failedTestNames: ["shouldToggleState"],
    };

    const result = evaluateVerificationState(verification, 3);
    expect(result.action).toBe("RETRY_IMPLEMENTATION");
    expect(result.remainingRetries).toBe(2);
  });

  it("activa el circuit breaker de escalado si retriesLeft llega a 1 y falla", () => {
    const verification: VerificationResult = {
      passed: false,
      typeCheckPassed: false,
      unitTestsPassed: false,
      output: "TS2322: Type 'string' is not assignable to type 'number'",
      failedTestNames: [],
    };

    const result = evaluateVerificationState(verification, 1);
    expect(result.action).toBe("ESCALATE_LIMIT_REACHED");
    expect(result.remainingRetries).toBe(0);
  });
});
